# Tether USD

## Contract Information
- **Contract Name:** TetherToken
- **Compiler Version:** v0.4.18+commit.9cf6e910
- **Optimization Enabled:** No
- **Contract Address:** 0xdAC17F958D2ee523a2206206994597C13D831ec7
- **EVM Version:** default
- **Chain:** Ethereum Mainnet
- **Creator:** 0x36928500bc1dcd7af6a2b4008875cc336b927d57
- **Creation Transaction:** 0x2f1c5c2b44f771e942a8506148e256f94f1a464babc938ae0690c6e34cd79190

## Source Code Structure
```
└── TetherToken.sol

```